POCKET_OPTION_EMAIL = "ton.email@example.com"
POCKET_OPTION_PASSWORD = "tonMotDePasse"